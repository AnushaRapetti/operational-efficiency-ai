# ⚙️ AI-Based Operational Efficiency Platform

> **Tech Stack:** Python · Scikit-Learn · SQL · Power BI · Tableau · Azure ML  
> **Domain:** Enterprise Operations | Banking Back-Office | Process Intelligence  
> **Author:** Anusha Rapetti — AI Product Owner

---

## 📌 Project Overview

A predictive AI platform that identifies operational inefficiencies, detects bottleneck departments, and projects cost savings — replacing manual Excel reporting with automated, real-time leadership dashboards.

### 🎯 Key Outcomes
| Metric | Result |
|---|---|
| Operational Efficiency | ↑ **22% improvement** across enterprise units |
| Annual Cost Savings | **₹1.5 Cr** reduction in operational overhead |
| Manual Reporting Effort | ↓ **60% eliminated** through automation |
| Real-Time Monitoring | Leadership dashboards live — zero manual refresh |

---

## 🧠 Architecture

```
Operations Data (Departments, Shifts, Tasks)
         │
         ▼
  ┌──────────────────┐
  │  Feature Engine   │  ← inefficiency index, automation gap, completion rate
  └────────┬─────────┘
           │
    ┌──────┴─────────┐
    │                │
    ▼                ▼
Efficiency        Bottleneck
Predictor         Detector
(GBM Regressor)  (Rule + Stats)
    │                │
    └──────┬─────────┘
           │
    Cost Savings
    Estimator
           │
    ┌──────▼──────────┐
    │  Dashboard CSV   │  → Power BI / Tableau / SQL Server
    └──────────────────┘
           │
    Leadership Dashboard
    (Real-time KPIs + Alerts)
```

---

## 🔧 Features

### 1. Predictive Efficiency Model
- **Algorithm:** Gradient Boosting Regressor
- **Target:** Operational efficiency score (0–100)
- **Key Signals:** Automation coverage, rework rate, system downtime, SLA breaches, training hours
- **Purpose:** Predict efficiency before SLA breach — enabling proactive intervention

### 2. Bottleneck Detector
- Statistical detection of underperforming departments
- Flags units with efficiency > 1 SD below mean OR high SLA breach count
- Generates actionable department-level insights for ops leadership

### 3. Cost Savings Estimator
- Projects monthly and annual savings from efficiency improvement
- Demonstrates ₹1.5 Cr impact calculation for executive reporting
- Configurable efficiency uplift percentage

### 4. Power BI / Tableau-Ready Export
- Scored CSV output with: efficiency score, prediction, delta, alert flag
- Compatible with direct Power BI Desktop import or Azure SQL pipeline
- Department-level and time-series ready fields

---

## 🚀 Quick Start

```bash
# 1. Clone the repo
git clone https://github.com/anusha-rapetti/operational-efficiency-ai.git
cd operational-efficiency-ai

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the full pipeline
python operational_efficiency_ai.py
```

### Sample Output
```
══════════════════════════════════════════════════════
  AI-Based Operational Efficiency Platform
══════════════════════════════════════════════════════

[1/5] Generating operations data...
  Records loaded       : 6,000
  Departments          : 6
  Avg efficiency score : 71.4 / 100

── Predictive Efficiency Model (GBM Regressor) ──
  Mean Absolute Error : 2.14 points
  R² Score            : 0.9421

── Bottleneck Detection ──
  ⚠️  Bottleneck Departments (2):
    → KYC & Compliance | Eff: 64.1 | SLA Breaches: 842
    → Trade Finance    | Eff: 61.8 | SLA Breaches: 761

── Cost Savings Estimation ──
  ✅ Projected Annual Saving: ₹1,51,20,000 (~₹151.2 Lakhs)

  📊 Dashboard data exported → ops_dashboard_data.csv
```

---

## 📦 Requirements

```
scikit-learn>=1.3.0
pandas>=2.0.0
numpy>=1.24.0
matplotlib>=3.7.0
seaborn>=0.12.0
```

---

## 🗂️ Project Structure

```
operational-efficiency-ai/
├── operational_efficiency_ai.py   # Core ML pipeline
├── ops_dashboard_data.csv         # Auto-generated dashboard export
├── requirements.txt
└── README.md
```

---

## 📊 Dashboard Integration Guide

### Power BI Connection
1. Run the pipeline → `ops_dashboard_data.csv` is generated
2. Open Power BI Desktop → Get Data → CSV
3. Create visuals:
   - **KPI Card:** avg efficiency score
   - **Bar Chart:** efficiency by department
   - **Line Chart:** efficiency trend over time (month_label)
   - **Table:** alert_flag = 1 records (bottleneck monitor)

### SQL Server Integration (Production Pattern)
```python
# In production: replace CSV export with SQL write
import pyodbc
conn = pyodbc.connect("DSN=AzureSQL;...")
df[export_cols].to_sql("ops_efficiency_scores", conn, if_exists="append")
```

---

## 💼 Business Context

Designed to replace manual Excel-based operational reporting in enterprise banking environments. Key design decisions:

- **GBM over Linear Regression** — captures non-linear interactions (e.g. automation only helps when rework is low AND downtime is controlled)
- **Statistical bottleneck detection** — self-calibrating thresholds adapt to org performance vs. fixed rules
- **Power BI-first output** — ensures adoption by ops leaders without technical onboarding
- **Cost savings model** — ties AI output to ₹ impact for CFO-level reporting

---

## 📬 Connect

**Anusha Rapetti** — AI Product Owner | Banking & Fintech AI  
📧 anusha.ra539@gmail.com  
🔗 [linkedin.com/in/anusha-rapetti-07a911264](https://linkedin.com/in/anusha-rapetti-07a911264)  
📍 Hyderabad → Dubai (Relocating)
